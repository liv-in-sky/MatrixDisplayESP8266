var searchData=
[
  ['texteffect_5ft',['textEffect_t',['../_m_d___parola_8h.html#acf3b849a996dbbe48ca173d2b0b82eda',1,'MD_Parola.h']]],
  ['textposition_5ft',['textPosition_t',['../_m_d___parola_8h.html#abab52de9e46b83d0aa94f0e3439e224d',1,'MD_Parola.h']]],
  ['time_5fprofiling',['TIME_PROFILING',['../_m_d___parola__lib_8h.html#ad5074ed4add7f6c0b8052896efd82cd3',1,'MD_Parola_lib.h']]]
];
